#include <stdio.h>

extern int addmod();

int main() {
  
  printf( "Lab 01 - Simple adding machine\n" );
  addmod();

}
